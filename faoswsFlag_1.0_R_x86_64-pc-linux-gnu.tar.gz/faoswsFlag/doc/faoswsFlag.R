
## ----setup, include=FALSE, cache=FALSE-----------------------------------
library(knitr)
opts_chunk$set(fig.path='figure/', fig.align='center', fig.show='hold',
               warning=FALSE, message=FALSE, error=FALSE, tidy=FALSE, 
               results='markup', eval=TRUE, echo=TRUE, cache=FALSE)
options(replace.assign=TRUE,width=80)
assign("depthtrigger", 10, data.table:::.global)


## ----load-libraries------------------------------------------------------
## Load the required libraries
library(faoswsFlag)
library(ggplot2)
library(splines)



## ----flag-table----------------------------------------------------------

## Printed here is the default flag conversion table shipped with the
## package.
faoswsFlagTable


## ----aggregate-flag1-----------------------------------------------------
## The function works just like sum(), with an optional arguement for
## the flag table to be used.
aggregateObservationFlag("", "T", flagTable = faoswsFlagTable)


## ----aggregate-flag2-----------------------------------------------------
## Aggregation of multiple flag

## Simulate flag for production
simulatedProductionFlag = 
    faoswsFlagTable[sample(1:NROW(faoswsFlagTable), 10, replace = TRUE),
                    "flagObservationStatus"]
simulatedProductionFlag

## Simulated flag for area harvested
simulatedAreaFlag = 
    faoswsFlagTable[sample(1:NROW(faoswsFlagTable), 10, replace = TRUE),
                    "flagObservationStatus"]
simulatedAreaFlag

## Now compute the aggregation of flag
aggregateObservationFlag(simulatedProductionFlag, simulatedAreaFlag, 
                         flagTable = faoswsFlagTable)


## ----simulated-example, fig.height=5-------------------------------------
## New table for simulation.
simTable = faoswsFlagTable
simTable[simTable$flagObservationStatus == "E", 
         "flagObservationWeights"] = 0.4

## Simuate a data set which has a single point that was imputed badly 
## but still used for later analysis.
x = 1991:2014
y = 100 + 10 * (x - 1989) + rnorm(length(x), sd = 30)
f = rep("T", length(x))
y[23:24] = c(80, 90)
f[23:24] = "E"
simulated.df = data.frame(year = x, simulatedProduction = y, flag = f)

## Plot the data and show the two different fit when accounting for the 
## source and quality of information.
ggplot(data = simulated.df, 
       aes(x = year, y = simulatedProduction, label = flag)) + 
    geom_text() + 
    geom_smooth(method = "lm", formula = y ~ x, 
                data = simulated.df, se = FALSE, col = "red") + 
    geom_smooth(method = "lm", formula = y ~ x, 
                aes(weight = flag2weight(flag, flagTable = simTable)),
                data = simulated.df, se = FALSE)




## ----simulated-example2, fig.height=5------------------------------------
x = 1991:2014
y = 100 + c(10, 15) * (x - 1989)^2 + rnorm(length(x), sd = 20)
f = rep(c("E", "T"), length(x)/2)
simulated.df = data.frame(year = x, simulatedProduction = y, flag = f)

## Plot the data and show the two different fit when accounting for the 
## source and quality of information.
ggplot(data = simulated.df, 
       aes(x = year, y = simulatedProduction, label = flag)) + 
    geom_text() + 
    geom_smooth(method = "lm", formula = y ~ bs(x), 
                data = simulated.df, se = FALSE, col = "red") + 
    geom_smooth(method = "lm", formula = y ~ bs(x), 
                aes(weight = flag2weight(flag, flagTable = simTable)),
                data = simulated.df, se = FALSE)





## ----compute-weight, eval=FALSE------------------------------------------
## ## load the library
## library(faosws)
## library(faoswsExtra)
## library(faoswsFlag)
## library(data.table)
## library(FAOSTAT)
## 
## ## Set up the data query
## newPivot = c(
##     Pivoting(code= "geographicAreaM49", ascending = TRUE),
##     Pivoting(code= "measuredItemCPC", ascending = TRUE),
##     Pivoting(code = "timePointYears", ascending = FALSE),
##     Pivoting(code= "measuredElement", ascending = TRUE)
##     )
## 
## newKey = swsContext.datasets
## 
## getAllCountryCode = function(){
##     ## 1062 is geographical world
##     keyTree =
##         unique(GetCodeTree(domain = swsContext.datasets[[1]]@domain,
##                            dataset = swsContext.datasets[[1]]@dataset,
##                            dimension = "geographicAreaM49",
##                            roots = "1062")
##                )
##     allCountryCode =
##         unique(adjacent2edge(keyTree)$children)
##     allCountryCode[allCountryCode %in% FAOcountryProfile$UN_CODE]
## }
## 
## ## Create new key and download data, the history is for the whole
## ## world since 1970 for wheat.
## newKey[[1]]@dimensions$geographicAreaM49@keys = getAllCountryCode()
## newKey[[1]]@dimensions$timePointYears@keys = as.character(1970:2013)
## newKey[[1]]@dimensions$measuredItemCPC@keys = "0111"
## 
## ## Compute the table
## history = GetHistory(newKey[[1]], newPivot)
## history[, timePointYears := as.numeric(timePointYears)]
## obsTable = computeFlagWeight(history, method = "entropy")
## 
## 
## 


